import './App.css'
import Home from './views/Home'

function App() {

  return (
    <>
      <Home />
    </>
  )
}

export default App
